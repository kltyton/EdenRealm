package io.github.kltyton.kltytonui.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.vertex.PoseStack;
import io.github.kltyton.kltytonui.KltytonUI;
import io.github.kltyton.kltytonui.dev.DevTools;
import io.github.kltyton.kltytonui.dev.ResourceManager;
import io.github.kltyton.kltytonui.event.MouseEvent;
import io.github.kltyton.kltytonui.init.Document;
import io.github.kltyton.kltytonui.task.FrameScheduler;
import io.github.kltyton.kltytonui.task.MouseMoveEngine;
import io.github.kltyton.kltytonui.render.Operation;
import io.github.kltyton.kltytonui.render.DocumentLayerOrder;
import io.github.kltyton.kltytonui.style.Cursor;
import io.github.kltyton.kltytonui.layout.Position;
import io.github.kltyton.kltytonui.layout.Size;
import io.github.kltyton.kltytonui.neoforge.RenderService;
import io.github.kltyton.kltytonui.style.Text;
import net.minecraft.ChatFormatting;
import net.minecraft.util.StringUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.FlipFrameEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import io.github.kltyton.kltytonui.resource.Font;
import io.github.kltyton.kltytonui.config.KltytonUIConfig;
import io.github.kltyton.kltytonui.world.WorldWindow;

@EventBusSubscriber(modid = KltytonUI.MODID, value = Dist.CLIENT)
public class Client {
    public static final HashMap<String, Integer> KEY_MAP = new HashMap<>();
    private static int lastWindowWidth = -1;
    private static int lastWindowHeight = -1;
    private static int lastFramebufferWidth = -1;
    private static int lastFramebufferHeight = -1;
    private static double lastGuiScale = -1.0d;

    @SubscribeEvent
    public static void endRenderFrame(FlipFrameEvent event) {
        RenderService.INSTANCE.endFrame();
    }

    static {
        KEY_MAP.put("key.keyboard.unknown", -1);
        KEY_MAP.put("key.mouse.left", 0);
        KEY_MAP.put("key.mouse.right", 1);
        KEY_MAP.put("key.mouse.middle", 2);
        KEY_MAP.put("key.mouse.4", 3);
        KEY_MAP.put("key.mouse.5", 4);
        KEY_MAP.put("key.mouse.6", 5);
        KEY_MAP.put("key.mouse.7", 6);
        KEY_MAP.put("key.mouse.8", 7);
        KEY_MAP.put("key.keyboard.0", 48);
        KEY_MAP.put("key.keyboard.1", 49);
        KEY_MAP.put("key.keyboard.2", 50);
        KEY_MAP.put("key.keyboard.3", 51);
        KEY_MAP.put("key.keyboard.4", 52);
        KEY_MAP.put("key.keyboard.5", 53);
        KEY_MAP.put("key.keyboard.6", 54);
        KEY_MAP.put("key.keyboard.7", 55);
        KEY_MAP.put("key.keyboard.8", 56);
        KEY_MAP.put("key.keyboard.9", 57);
        KEY_MAP.put("key.keyboard.a", 65);
        KEY_MAP.put("key.keyboard.b", 66);
        KEY_MAP.put("key.keyboard.c", 67);
        KEY_MAP.put("key.keyboard.d", 68);
        KEY_MAP.put("key.keyboard.e", 69);
        KEY_MAP.put("key.keyboard.f", 70);
        KEY_MAP.put("key.keyboard.g", 71);
        KEY_MAP.put("key.keyboard.h", 72);
        KEY_MAP.put("key.keyboard.i", 73);
        KEY_MAP.put("key.keyboard.j", 74);
        KEY_MAP.put("key.keyboard.k", 75);
        KEY_MAP.put("key.keyboard.l", 76);
        KEY_MAP.put("key.keyboard.m", 77);
        KEY_MAP.put("key.keyboard.n", 78);
        KEY_MAP.put("key.keyboard.o", 79);
        KEY_MAP.put("key.keyboard.p", 80);
        KEY_MAP.put("key.keyboard.q", 81);
        KEY_MAP.put("key.keyboard.r", 82);
        KEY_MAP.put("key.keyboard.s", 83);
        KEY_MAP.put("key.keyboard.t", 84);
        KEY_MAP.put("key.keyboard.u", 85);
        KEY_MAP.put("key.keyboard.v", 86);
        KEY_MAP.put("key.keyboard.w", 87);
        KEY_MAP.put("key.keyboard.x", 88);
        KEY_MAP.put("key.keyboard.y", 89);
        KEY_MAP.put("key.keyboard.z", 90);
        KEY_MAP.put("key.keyboard.f1", 290);
        KEY_MAP.put("key.keyboard.f2", 291);
        KEY_MAP.put("key.keyboard.f3", 292);
        KEY_MAP.put("key.keyboard.f4", 293);
        KEY_MAP.put("key.keyboard.f5", 294);
        KEY_MAP.put("key.keyboard.f6", 295);
        KEY_MAP.put("key.keyboard.f7", 296);
        KEY_MAP.put("key.keyboard.f8", 297);
        KEY_MAP.put("key.keyboard.f9", 298);
        KEY_MAP.put("key.keyboard.f10", 299);
        KEY_MAP.put("key.keyboard.f11", 300);
        KEY_MAP.put("key.keyboard.f12", 301);
        KEY_MAP.put("key.keyboard.f13", 302);
        KEY_MAP.put("key.keyboard.f14", 303);
        KEY_MAP.put("key.keyboard.f15", 304);
        KEY_MAP.put("key.keyboard.f16", 305);
        KEY_MAP.put("key.keyboard.f17", 306);
        KEY_MAP.put("key.keyboard.f18", 307);
        KEY_MAP.put("key.keyboard.f19", 308);
        KEY_MAP.put("key.keyboard.f20", 309);
        KEY_MAP.put("key.keyboard.f21", 310);
        KEY_MAP.put("key.keyboard.f22", 311);
        KEY_MAP.put("key.keyboard.f23", 312);
        KEY_MAP.put("key.keyboard.f24", 313);
        KEY_MAP.put("key.keyboard.f25", 314);
        KEY_MAP.put("key.keyboard.num.lock", 282);
        KEY_MAP.put("key.keyboard.keypad.0", 320);
        KEY_MAP.put("key.keyboard.keypad.1", 321);
        KEY_MAP.put("key.keyboard.keypad.2", 322);
        KEY_MAP.put("key.keyboard.keypad.3", 323);
        KEY_MAP.put("key.keyboard.keypad.4", 324);
        KEY_MAP.put("key.keyboard.keypad.5", 325);
        KEY_MAP.put("key.keyboard.keypad.6", 326);
        KEY_MAP.put("key.keyboard.keypad.7", 327);
        KEY_MAP.put("key.keyboard.keypad.8", 328);
        KEY_MAP.put("key.keyboard.keypad.9", 329);
        KEY_MAP.put("key.keyboard.keypad.add", 334);
        KEY_MAP.put("key.keyboard.keypad.decimal", 330);
        KEY_MAP.put("key.keyboard.keypad.enter", 335);
        KEY_MAP.put("key.keyboard.keypad.equal", 336);
        KEY_MAP.put("key.keyboard.keypad.multiply", 332);
        KEY_MAP.put("key.keyboard.keypad.divide", 331);
        KEY_MAP.put("key.keyboard.keypad.subtract", 333);
        KEY_MAP.put("key.keyboard.down", 264);
        KEY_MAP.put("key.keyboard.left", 263);
        KEY_MAP.put("key.keyboard.right", 262);
        KEY_MAP.put("key.keyboard.up", 265);
        KEY_MAP.put("key.keyboard.apostrophe", 39);
        KEY_MAP.put("key.keyboard.backslash", 92);
        KEY_MAP.put("key.keyboard.comma", 44);
        KEY_MAP.put("key.keyboard.equal", 61);
        KEY_MAP.put("key.keyboard.grave.accent", 96);
        KEY_MAP.put("key.keyboard.left.bracket", 91);
        KEY_MAP.put("key.keyboard.minus", 45);
        KEY_MAP.put("key.keyboard.period", 46);
        KEY_MAP.put("key.keyboard.right.bracket", 93);
        KEY_MAP.put("key.keyboard.semicolon", 59);
        KEY_MAP.put("key.keyboard.slash", 47);
        KEY_MAP.put("key.keyboard.space", 32);
        KEY_MAP.put("key.keyboard.tab", 258);
        KEY_MAP.put("key.keyboard.left.alt", 342);
        KEY_MAP.put("key.keyboard.left.control", 341);
        KEY_MAP.put("key.keyboard.left.shift", 340);
        KEY_MAP.put("key.keyboard.left.win", 343);
        KEY_MAP.put("key.keyboard.right.alt", 346);
        KEY_MAP.put("key.keyboard.right.control", 345);
        KEY_MAP.put("key.keyboard.right.shift", 344);
        KEY_MAP.put("key.keyboard.right.win", 347);
        KEY_MAP.put("key.keyboard.enter", 257);
        KEY_MAP.put("key.keyboard.escape", 256);
        KEY_MAP.put("key.keyboard.backspace", 259);
        KEY_MAP.put("key.keyboard.delete", 261);
        KEY_MAP.put("key.keyboard.end", 269);
        KEY_MAP.put("key.keyboard.home", 268);
        KEY_MAP.put("key.keyboard.insert", 260);
        KEY_MAP.put("key.keyboard.page.down", 267);
        KEY_MAP.put("key.keyboard.page.up", 266);
        KEY_MAP.put("key.keyboard.caps.lock", 280);
        KEY_MAP.put("key.keyboard.pause", 284);
        KEY_MAP.put("key.keyboard.scroll.lock", 281);
        KEY_MAP.put("key.keyboard.menu", 348);
        KEY_MAP.put("key.keyboard.print.screen", 283);
        KEY_MAP.put("key.keyboard.world.1", 161);
        KEY_MAP.put("key.keyboard.world.2", 162);
    }

    @SubscribeEvent
    public static void scroll(InputEvent.MouseScrollingEvent event) {
        if (Minecraft.getInstance().gui.screen() != null) return;
        if (handleViewportZoomAtMouse(event.getScrollDeltaY() > 0)) {
            event.setCanceled(true);
            return;
        }
        boolean nativeConsumed = Operation.scroll(event.getScrollDeltaY());
        for (WorldWindow window : new ArrayList<>(WorldWindow.windows)) {
            Position realPos = window.getRealPos();
            if (realPos != null) {
                MouseEvent mouseEvent = new MouseEvent("wheel", realPos);
                mouseEvent.deltaY = -event.getScrollDeltaY() * 50;
                mouseEvent.scrollDelta = mouseEvent.deltaY;
                mouseEvent.cancelable = true;
                MouseEvent.tiggerEvent(mouseEvent, window.document);
                nativeConsumed |= mouseEvent.isNativeConsumed();
            }
        }
        if (nativeConsumed || CursorReleaseController.isActive()) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void scroll(ScreenEvent.MouseScrolled.Pre event) {
        if (handleViewportZoomAtMouse(event.getScrollDeltaY() > 0)) {
            event.setCanceled(true);
            return;
        }
        if (Operation.scroll(event.getScrollDeltaY())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onCharTyped(ScreenEvent.CharacterTyped.Pre event) {
        if (StringUtil.isAllowedChatCharacter(event.getCodePoint())) {
            if (Operation.onCharTyped(event.getCodePoint())) event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void mouseButton(InputEvent.MouseButton.Pre event) {
        if (Minecraft.getInstance().gui.screen() != null) return;
        boolean nativeConsumed = false;
        if (event.getAction() == InputConstants.PRESS) nativeConsumed = Operation.onMouseDown(event.getButton());
        if (event.getAction() == InputConstants.RELEASE) nativeConsumed = Operation.onMouseUp(event.getButton());
        boolean devToolsInspectConsumed = Operation.wasDevToolsInspectConsumed();
        // DevTools picking is an inspection gesture, not an application click.
        if (devToolsInspectConsumed) {
            event.setCanceled(true);
            return;
        }
        for (WorldWindow window : new ArrayList<>(WorldWindow.windows)) {
            Position realPos = window.getRealPos();
            if (realPos != null) {
                MouseEvent mouseEvent;
                if (event.getAction() == InputConstants.PRESS) {
                    mouseEvent = new MouseEvent("mousedown", realPos, event.getButton());
                } else {
                    mouseEvent = new MouseEvent("mouseup", realPos, event.getButton());
                }
                MouseEvent.tiggerEvent(mouseEvent, window.document);
                nativeConsumed |= mouseEvent.isNativeConsumed();
            }
        }
        if (nativeConsumed || CursorReleaseController.isActive()) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void mouseButton(ScreenEvent.MouseButtonPressed.Pre event) {
        if (Operation.onMouseDown(event.getButton(), new Position(event.getMouseX(), event.getMouseY()))) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void mouseButton(ScreenEvent.MouseButtonReleased.Pre event) {
        if (Operation.onMouseUp(event.getButton(), new Position(event.getMouseX(), event.getMouseY()))) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void mouseMove(RenderFrameEvent.Pre event) {
        io.github.kltyton.kltytonui.init.Window.window.fireAnimationFrame();
        // 渲染帧仅作轮询载具：60Hz 固定节拍由 MouseMoveEngine 调度，
        // 未到期时一次 nanoTime 比较即返回，不会随刷新率放大分发频率。
        MouseMoveEngine.poll(Client::getMousePosition);
    }

    /**
     * Tracks the pointer for DevTools element-inspection and screen tooltips
     * while a Minecraft Screen is open. The GUI layer (which calls
     * {@code DevTools.handleInspectMouseMove}) is disabled whenever a screen is
     * showing, so without this hook the translucent box-model highlight never
     * updates while inspecting on the title screen, a container screen, or the
     * pause screen (regression from the 1.21 {@code updateTooltipPosition}).
     */
    @SubscribeEvent
    public static void updateTooltipPosition(ScreenEvent.Render.Pre event) {
        Position mousePosition = new Position(event.getMouseX(), event.getMouseY());
        io.github.kltyton.kltytonui.ui.Tooltip.moveActiveFromScreen(mousePosition);
        DevTools.handleInspectMouseMove(mousePosition);
    }

    @SubscribeEvent
    public static void onKeyPressed(InputEvent.Key event) {
        if (Minecraft.getInstance().gui.screen() != null) {
            return;
        }
        int action = event.getAction();
        if (action != InputConstants.PRESS && action != InputConstants.REPEAT && action != InputConstants.RELEASE) return;
        if (action == InputConstants.PRESS && handleViewportZoomKeyAtMouse(event.getKey(), event.getModifiers())) {
            return;
        }
        boolean canceled = Operation.handleKeyInput(
                event.getKey(),
                event.getScanCode(),
                action,
                event.getModifiers(),
                action == InputConstants.REPEAT,
                io.github.kltyton.kltytonui.event.KeyEvent.Source.INPUT_EVENT
        );
//        if (canceled) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onScreenKeyPressed(ScreenEvent.KeyPressed.Pre event) {
        if (handleViewportZoomKeyAtMouse(event.getKeyCode(), event.getModifiers())) {
            event.setCanceled(true);
            return;
        }
        int action = InputConstants.PRESS;
        boolean canceled = Operation.handleKeyInput(
                event.getKeyCode(),
                event.getScanCode(),
                action,
                event.getModifiers(),
                false,
                io.github.kltyton.kltytonui.event.KeyEvent.Source.SCREEN_EVENT
        );
        if (canceled) event.setCanceled(true);
    }

    private static boolean handleViewportZoomAtMouse(boolean zoomIn) {
        if (!isControlDown()) return false;
        if (Operation.shouldBlockScreenMouseEvents()) return false;
        Document target = findViewportZoomTargetAtMouse();
        if (target == null) return false;
        KltytonUI.LOGGER.info("[KUI Viewport] wheel zoomIn={} target={}", zoomIn, target.getPath());
        return target.handleViewportZoom(zoomIn);
    }

    private static boolean handleViewportZoomKeyAtMouse(int keyCode, int modifiers) {
        if (!isControlModifier(modifiers)) return false;

        boolean zoomIn = keyCode == GLFW.GLFW_KEY_EQUAL || keyCode == GLFW.GLFW_KEY_KP_ADD;
        boolean zoomOut = keyCode == GLFW.GLFW_KEY_MINUS || keyCode == GLFW.GLFW_KEY_KP_SUBTRACT;
        boolean reset = keyCode == GLFW.GLFW_KEY_0 || keyCode == GLFW.GLFW_KEY_KP_0;
        if (!zoomIn && !zoomOut && !reset) return false;

        Document target = findViewportZoomTargetAtMouse();
        if (target == null) return false;
        KltytonUI.LOGGER.info("[KUI Viewport] key zoomIn={} reset={} target={}", zoomIn, reset, target.getPath());
        return reset ? target.resetViewportZoom() : target.handleViewportZoom(zoomIn);
    }

    private static Document findViewportZoomTargetAtMouse() {
        Position mouse = Operation.getMousePositionDirectly();
        if (mouse == null) return null;
        boolean passThrough = KltytonUIConfig.CLIENT.viewportZoomPassThrough.get();
        for (Document document : DocumentLayerOrder.frontToBack(Document.getAll())) {
            if (document == null || document.inWorld || document.isManuallyRendered() || !document.isActive()) continue;
            if (document.hitTest(document.screenToDocumentPosition(mouse)) != null) {
                if (passThrough && document.isReloadPersistent() && !document.interceptsMouseEvents()) {
                    continue;
                }
                return document;
            }
        }
        return null;
    }

    private static boolean isControlModifier(int modifiers) {
        return (modifiers & GLFW.GLFW_MOD_CONTROL) != 0 || isControlDown();
    }

    private static boolean isControlDown() {
        try {
            Window window = Minecraft.getInstance().getWindow();
            long handle = window == null ? 0L : window.handle();
            return handle != 0L
                    && (GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                    || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS);
        } catch (Throwable ignored) {
            return false;
        }
    }

    @SubscribeEvent
    public static void onScreenKeyReleased(ScreenEvent.KeyReleased.Pre event) {
        int action = InputConstants.RELEASE;
        Operation.handleKeyInput(
                event.getKeyCode(),
                event.getScanCode(),
                action,
                event.getModifiers(),
                false,
                io.github.kltyton.kltytonui.event.KeyEvent.Source.SCREEN_EVENT
        );
    }

    /**
     * 26.1 screens only collect render states; KUI documents and their item
     * nodes are rasterised together by the fullscreen Picture-in-Picture layer.
     */
    @SubscribeEvent
    public static void drawScreen(ScreenEvent.Render.Post event) {
        io.github.kltyton.kltytonui.render.FrameTimingHud.beginFrame();
        try {
            // KuiLinkedScreens submit the UI PIP state during extraction so
            // frame-local floating items join the same document pass. Other
            // screens submit the normal document state here.
            if (!(Minecraft.getInstance().gui.screen() instanceof io.github.kltyton.kltytonui.screen.KuiLinkedScreen)) {
                io.github.kltyton.kltytonui.client.gui.KltytonGuiLayers.submitUi(event.getGuiGraphics());
            }
            io.github.kltyton.kltytonui.client.gui.KltytonGuiLayers.submitCursor(event.getGuiGraphics());
        } finally {
            io.github.kltyton.kltytonui.render.FrameTimingHud.endFrame();
            drawFrameTimingHud(event.getGuiGraphics());
        }
    }

    @SubscribeEvent
    public static void tick(ClientTickEvent.Pre event) {        CursorReleaseController.tick();
            ClientRuntimeSelfTest.tick();
            io.github.kltyton.kltytonui.loader.ClientLoaderForge.tickTemplateScanRetry();
            if (KltytonUIConfig.consumeClientReloadPending()) {
                io.github.kltyton.kltytonui.dev.debug.ExternalDebugServer.reconcileConfiguration();
            }
            io.github.kltyton.kltytonui.dev.debug.ExternalDebugServer.tick();
            FrameScheduler.tick();
            DebugReloadWatcher.tick();
            DevTools.drainLogs();
            Window mcWindow = Minecraft.getInstance().getWindow();
            int w = mcWindow.getScreenWidth();
            int h = mcWindow.getScreenHeight();
            int framebufferWidth = mcWindow.getWidth();
            int framebufferHeight = mcWindow.getHeight();
            double guiScale = mcWindow.getGuiScale();
            if (lastWindowWidth != w || lastWindowHeight != h
                    || lastFramebufferWidth != framebufferWidth
                    || lastFramebufferHeight != framebufferHeight
                    || Double.compare(lastGuiScale, guiScale) != 0) {
                lastWindowWidth = w;
                lastWindowHeight = h;
                lastFramebufferWidth = framebufferWidth;
                lastFramebufferHeight = framebufferHeight;
                lastGuiScale = guiScale;
                for (Document document : Document.getAll()) {
                    if (document != null && !document.isDisposed()) {
                        document.applyViewport(true);
                    }
                }
                io.github.kltyton.kltytonui.init.Window.window.fireResizeEvent();
        }
    }

    /**
     * FIXME:
     * 如果在某些情况（如窗口拖动等）鼠标位置缓存为空或者是读到旧的缓存值时请参考 {@link #getMousePositionDirectly()} 的实现。
     * 未来建议重构，统一输入源，或在输入更新链中保证鼠标坐标始终同步。
     *
     * @see Operation#getMousePosition()
     */
    public static Position getMousePosition() {
        Minecraft mc = Minecraft.getInstance();
        MouseHandler mouseHandler = mc.mouseHandler;
        Window window = mc.getWindow();

        return MouseCoordinates.toGui(mouseHandler.xpos(), mouseHandler.ypos(),
                window.getScreenWidth(), window.getScreenHeight(),
                window.getGuiScaledWidth(), window.getGuiScaledHeight());
    }

    /**
     * Returns the pointer position represented by the screen for world-window picking.
     * A grabbed GLFW cursor has virtual coordinates that track look movement, while
     * the visible crosshair remains fixed at the center of the GUI viewport.
     */
    public static Position getMousePositionForWorldInteraction() {
        Minecraft mc = Minecraft.getInstance();
        Window window = mc.getWindow();
        if (mc.mouseHandler.isMouseGrabbed()) {
            return new Position(
                    window.getGuiScaledWidth() * 0.5d,
                    window.getGuiScaledHeight() * 0.5d
            );
        }
        return getMousePosition();
    }

    /** Returns the live cursor position directly from the GLFW window handle. */
    public static Position getMousePositionDirectly() {
        Window window = Minecraft.getInstance().getWindow();
        long handle = window.handle();
        if (handle != 0L) {
            double[] xBuf = new double[1];
            double[] yBuf = new double[1];
            GLFW.glfwGetCursorPos(handle, xBuf, yBuf);
            return MouseCoordinates.toGui(xBuf[0], yBuf[0],
                    window.getScreenWidth(), window.getScreenHeight(),
                    window.getGuiScaledWidth(), window.getGuiScaledHeight());
        }
        return null;
    }

    public static boolean isKeyPressed(String keyName) {
        if (keyName == null || keyName.isEmpty()) {
            return false;
        }

        Minecraft minecraft = Minecraft.getInstance();
        long windowHandle = minecraft.getWindow().handle();
        if (windowHandle == 0L) return false;

        try {
            Integer glfwKey = KEY_MAP.get(keyName);
            if (glfwKey == null) {
                return false;
            }

            if (keyName.startsWith("key.mouse.")) {
                return GLFW.glfwGetMouseButton(windowHandle, glfwKey) == GLFW.GLFW_PRESS;
            }

            if (keyName.startsWith("key.keyboard.")) {
                return GLFW.glfwGetKey(windowHandle, glfwKey) == GLFW.GLFW_PRESS;
            }

            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public static Window getWindow() {
        return Minecraft.getInstance().getWindow();
    }

    public static Size getWindowSize() {
        Window window = Minecraft.getInstance().getWindow();
        return new Size(window.getGuiScaledWidth(), window.getGuiScaledHeight());
    }

    public static int getDefaultFontWidth(String text) {
        return getDefaultFontWidth(text, false, false, 0);
    }

    public static int getDefaultFontWidth(String text, boolean bold) {
        return getDefaultFontWidth(text, bold, false, 0);
    }

    public static int getDefaultFontWidth(String text, boolean bold, boolean oblique) {
        return getDefaultFontWidth(text, bold, oblique, 0);
    }

    public static int getDefaultFontWidth(String text, boolean bold, boolean oblique, double strokeWidth) {
        double stroke = Math.max(0, strokeWidth) * 2;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft == null || minecraft.font == null) {
            int fontStyle = java.awt.Font.PLAIN;
            if (bold) fontStyle |= java.awt.Font.BOLD;
            if (oblique) fontStyle |= java.awt.Font.ITALIC;
            java.awt.Font fallbackFont = new java.awt.Font("Microsoft YaHei", fontStyle, 16);
            int width = new java.awt.Canvas().getFontMetrics(fallbackFont).stringWidth(text == null ? "" : text);
            return (int) Math.ceil(width + stroke);
        }
        if (!bold && !oblique) return (int) Math.ceil(minecraft.font.width(text) + stroke);
        MutableComponent renderText = Component.literal(text);
        if (bold) renderText = renderText.withStyle(ChatFormatting.BOLD);
        if (oblique) renderText = renderText.withStyle(ChatFormatting.ITALIC);
        return (int) Math.ceil(minecraft.font.width(renderText) + stroke);
    }

    public static void drawDefaultFont(PoseStack poseStack, Text text, String content, Position position) {
        poseStack.pushPose();
        poseStack.translate(position.x, position.y, 0);
        // 默认字体也要保留 z 轴缩放，避免在容器 Screen 中把文本深度压扁后被后续菜单/物品绘制覆盖。
        float scale = (float) text.defaultFontScale();
        poseStack.scale(scale, scale, 1f);
        MutableComponent renderText = Component.literal(content == null ? "" : content);
        if (text.isBold()) renderText = renderText.withStyle(ChatFormatting.BOLD);
        if (text.isOblique()) renderText = renderText.withStyle(ChatFormatting.ITALIC);
        if (text.isUnderlined()) renderText = renderText.withStyle(ChatFormatting.UNDERLINE);
        if (text.isStrikethrough()) renderText = renderText.withStyle(ChatFormatting.STRIKETHROUGH);
        int stroke = Math.max(0, (int) Math.ceil(text.strokeWidth));
        if (stroke > 0) {
            int strokeColor = text.strokeColor.getValue();
            for (int ox = -stroke; ox <= stroke; ox++) {
                for (int oy = -stroke; oy <= stroke; oy++) {
                    if (ox == 0 && oy == 0) continue;
                    if (ox * ox + oy * oy > stroke * stroke) continue;
                    RenderService.INSTANCE.drawNativeText(Minecraft.getInstance().font,
                            renderText.getVisualOrderText(), poseStack, ox, oy, strokeColor, false, 15728880);
                }
            }
        }
        RenderService.INSTANCE.drawNativeText(Minecraft.getInstance().font,
                renderText.getVisualOrderText(), poseStack, 0, 0, text.color.getValue(), false, 15728880);
        poseStack.popPose();
    }

    public static void drawDefaultFont(PoseStack poseStack, Text text, Position position) {
        drawDefaultFont(poseStack, text, text.content, position);
    }

    /** Draws the frame-timing HUD overlay, if enabled. */
    public static void drawFrameTimingHud(net.minecraft.client.gui.GuiGraphicsExtractor guiGraphics) {
        if (guiGraphics == null || !io.github.kltyton.kltytonui.render.FrameTimingHud.isEnabled()) return;
        String text = io.github.kltyton.kltytonui.render.FrameTimingHud.frameStatsText();
        if (text == null) return;
        Minecraft minecraft = Minecraft.getInstance();
        int width = minecraft.font.width(text) + 8;
        guiGraphics.pose().pushMatrix();
        guiGraphics.fill(2, 2, 2 + width, 16, 0xCC000000);
        guiGraphics.text(minecraft.font, text, 6, 6, 0xFF00FF66, false);
        guiGraphics.pose().popMatrix();
    }

}
